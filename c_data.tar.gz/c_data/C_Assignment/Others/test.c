

#include<stdio.h>

int main()
{
	int x[5] = {1,2,3,4,5};

	printf("\nx=%d, x+1=%d, &x=%d, &x+1=%d\n", x, x+1, &x, &x+1);
	return 0;
}
