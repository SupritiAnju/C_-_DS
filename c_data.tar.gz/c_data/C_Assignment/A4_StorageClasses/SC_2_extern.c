/*1. Develop multi file program to understand static, auto, register, global, static global variables.What
is the scope and lifetime of each of these types of variables.*/


	
	int s=5;
	


	

	
	
